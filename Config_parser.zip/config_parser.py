file1 = open("config1.txt", "r", encoding='cp1251', errors='ignore', newline='')
file2 = open("config2.txt", "r", encoding='cp1251', errors='ignore', newline='')

def parametersExtractor(file):
    lines = file.readlines()
    params = {}
    for line in lines:
        fchar = line[0]
        if fchar == '#' or fchar =='\r' or fchar == '\t':
            continue
        splitline = line.split()
        params[splitline[0]] = splitline[1]
    return params

config1 = parametersExtractor(file1)
config2 = parametersExtractor(file2)

pset = set(config1.keys())
pset.update(config2.keys())

for p in pset:
    v1 = config1[p]
    v2 = config2[p]
    print("{:<60} | {:<50} | {:<50} ".format(p, v1, v2))